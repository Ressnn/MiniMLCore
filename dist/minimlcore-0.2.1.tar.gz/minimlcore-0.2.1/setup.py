# -*- coding: utf-8 -*-
"""
Created on Sat Apr 18 17:02:38 2020

@author: Pranav Devarinti
"""


from setuptools import setup

setup(name="minimlcore",version='0.2.1',description="A small ML Core",author="Pranav Devarinti",author_email="prdevarinti@gmail.com",license='MIT',packages=['MiniMLCore'],zip_safe=False)